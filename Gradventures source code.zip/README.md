
  # Make Screen Responsive

  This is a code bundle for Make Screen Responsive. The original project is available at https://www.figma.com/design/SkaqiufPCMvjRfFsZGBpLH/Make-Screen-Responsive.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  